مراحل گیت‌هاب — کامل و ساده (موبایل یا لپ‌تاپ)
==============================================

فایل‌های لازم داخل این پوشه:
- index.html   (بازی تو)
- nazer.html   (صفحه دوست)

A) ساخت مخزن
1) برو https://github.com  و لاگین کن.
2) بالا سمت راست + بزن → New repository
3) Repository name را بنویس: hyperfocus
4) Public را انتخاب کن
5) Add a README را تیک نزن
6) Create repository

B) آپلود فایل
1) روی صفحه مخزن خالی: uploading an existing file
   (یا Add file → Upload files)
2) index.html و nazer.html را بکش بینداز
3) پایین Commit changes را بزن

C) روشن کردن Pages (لینک سایت)
1) در مخزن برو Settings
2) از منوی چپ Pages
3) Branch را main بگذار، پوشه را / (root)
4) Save
5) یک دقیقه صبر کن
6) لینک این شکلی می‌شود:
   https://USERNAME.github.io/hyperfocus/
   USERNAME همان اسم اکانت گیت‌هاب توست

D) دو لینک
- بازی تو:
  https://USERNAME.github.io/hyperfocus/
- دوست (ناظر): داخل بازی دکمه «لینک ناظر برای دوست» را بزن تا لینک مخصوص کپی شود
  شکلش این است:
  https://USERNAME.github.io/hyperfocus/nazer.html?id=....

اگر github.io در ایران فیلتر بود، همان لینک را با یک DNS یا وقتی باز شد برای دوست بفرست.
اگر Pages بعد از ۵ دقیقه 404 داد، Settings → Pages را یک‌بار دیگر Save کن.
